$(".addbtn").hover(function(){
	$(this).addClass("addbtn2");
},function(){
	$(this).removeClass("addbtn2");
});

$(".delbtn").hover(function(){
	$(this).addClass("delbtn2");
},function(){
	$(this).removeClass("delbtn2");
});		

$(".copybtn").hover(function(){
	$(this).addClass("copybtn2");
},function(){
	$(this).removeClass("copybtn2");
});		
